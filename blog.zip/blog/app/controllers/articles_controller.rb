class ArticlesController < ApplicationController
  http_basic_authenticate_with name: "des", password: "123", except: [:index, :show]  



def index
    @articles = Article.all
   
  if params[:search]
    @articles = Article.search(params[:search])
  end





  end
 
  def show
    @article = Article.find(params[:id])
    abc = @article.view += 1
    @article.update_attribute "view", abc
   
  end

 def like
    @article = Article.find(params[:id])
    abc = @article.likep += 1
    @article.update_attribute "likep", abc
   
  end

 def dislike
    @article = Article.find(params[:id])
    abc = @article.dislikep += 1
    @article.update_attribute "dislikep", abc
   
  end

def reset
    @article = Article.find(params[:id])
    abc = @article.likep = 0
    @article.update_attribute "likep", abc
   
  end

 
  def new
  
    @article = Article.new
  end
 
  def edit
    @article = Article.find(params[:id])
  end
 
  def create
    @article = Article.new(article_params)
 
    if @article.save
      redirect_to @article
    else
      render 'new'
    end
  end
 
  def update
    @article = Article.find(params[:id])
 
    if @article.update(article_params)
      redirect_to @article
    else
      render 'edit'
    end
  end
 
  def destroy
    @article = Article.find(params[:id])
    @article.destroy
 
    redirect_to articles_path
  end
 
  private
    def article_params
      params.require(:article).permit(:title, :text, :theme, :view)
    end
end
