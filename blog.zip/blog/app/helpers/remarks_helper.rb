module RemarksHelper
end
