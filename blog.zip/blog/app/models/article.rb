class Article < ApplicationRecord

has_many :comments, dependent: :destroy
has_many :remarks, dependent: :destroy
  validates :title, presence: true,
                    length: { minimum: 5 }

def self.search(search)
 Article.order(:likep)
end




end
