class Count < ApplicationRecord
belong_to :article
end
