class Remark < ApplicationRecord
  belongs_to :article
end
