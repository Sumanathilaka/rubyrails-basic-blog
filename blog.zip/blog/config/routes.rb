Rails.application.routes.draw do
  get 'welcome/index'
 
 resources :articles do
  resources :comments
end

resources :articles do
  resources :remarks
end
 
  root 'welcome#index'

resources :articles do
  member do
   get 'like'
   get 'dislike'
   get 'reset'
  end
end


end
