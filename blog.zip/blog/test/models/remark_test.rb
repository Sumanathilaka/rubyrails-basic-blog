require 'test_helper'

class RemarkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
